﻿#include <iostream>
#include <iomanip>
#include <Windows.h>
#include <tlhelp32.h>
#include <Psapi.h>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif
#ifndef EXIT_FAILURE
#define EXIT_FAILURE 1
#endif
#ifndef EOF
#define EOF (-1)
#endif
#ifndef NULL
#define NULL 0
#endif
using namespace std;


class AutoAobi
{
private:
	DWORD processID = NULL;
	wstring processName = L"";
	HWND windowID = NULL;
	LPCWSTR windowClassName = L"";
	LPCWSTR windowTitle = L"";
	RECT windowRectangle{};
	
	/* Initialization */
	bool describe() const
	{
		if (this->windowID)
		{
			wcout << L"\tProcess ID = " << this->processID << endl;
			wcout << L"\tProcess Name = \"" << this->processName << L"\"" << endl;
			wcout << L"\tWindow ID = " << this->windowID << L" (" << (long long int)this->windowID << ")" << endl;
			if (this->windowClassName)
				wcout << L"\tWindow Class Name = \"" << this->windowClassName << L"\"" << endl;
			if (this->windowTitle)
				wcout << L"\tWindow Title = \"" << this->windowTitle << L"\"" << endl;
			wcout << L"\tleft = " << this->windowRectangle.left << L", right = " << this->windowRectangle.right << L", top = " << this->windowRectangle.top << L", bottom = " << this->windowRectangle.bottom << endl;
			wcout << L"\twidth = " << this->windowRectangle.right - this->windowRectangle.left << L", height = " << this->windowRectangle.bottom - this->windowRectangle.top << endl;
			return true;
		}
		else
			return false;
	}
	wstring loopChar(wchar_t ch, size_t t)
	{
		wstring wstr = L"";
		for (size_t i = 0; i < t; ++i)
			wstr += ch;
		return wstr;
	}
	bool getWindowRectangle()
	{
		if (GetWindowRect(this->windowID, &this->windowRectangle))
		{
			wcout << L"Target: " << endl;
			return this->describe();
		}
		else
		{
			wcout << L"Failed to fetch the details of the window rectangle with error code " << GetLastError() << L". " << endl;
			return false;
		}
	}
	bool getWindowID()
	{
		vector<HWND> hWnds{};
		vector<wstring> classNames{}, titleNames{};
		size_t widLength = 0, cnLength = 0, tnLength = 0;
		HWND hWnd = FindWindow(this->windowClassName, this->windowTitle);
		while (hWnd)
		{
			if (IsWindowVisible(hWnd))
			{
				DWORD windowProcessID = NULL;
				GetWindowThreadProcessId(hWnd, &windowProcessID);
				if (windowProcessID == this->processID)
				{
					/* HWND */
					hWnds.push_back(hWnd);
					wstringstream wss{};
					wss << hWnd;
					const size_t wLen = wss.str().length();
					if (wLen > widLength)
						widLength = wLen;

					/* Class Name */
					wchar_t className[MAX_PATH + 1] = { NULL };
					GetClassName(hWnd, className, MAX_PATH);
					classNames.push_back(className);
					const size_t cLen = classNames[classNames.size() - 1].length();
					if (cLen > cnLength)
						cnLength = cLen;

					/* Title Name */
					wchar_t titleName[MAX_PATH + 1] = { NULL }; //////
					GetWindowText(hWnd, titleName, MAX_PATH);
					titleNames.push_back(titleName);
					const size_t tLen = titleNames[titleNames.size() - 1].length();
					if (tLen > tnLength)
						tnLength = tLen;
				}
			}
			hWnd = FindWindowEx(NULL, hWnd, this->windowClassName, this->windowTitle);
		}
		
		if (hWnds.size() >= 2)
		{
			size_t choice = NULL;
			const size_t vectorLength = hWnds.size();
			const size_t indexLength = max(to_string(vectorLength - 1).size(), 5);
			widLength = max(widLength, 4);
			cnLength = max(cnLength, 10);
			tnLength = max(tnLength, 10);
			wcout << L"Multiple windows meet the requirements queried. " << endl << endl;
			wcout << L"    " << setw(indexLength) << L"Index" << L"    " << setw(widLength) << L"HWND" << L"    " << setw(cnLength) << L"Class Name" << L"    " << setw(tnLength) << "Title Name" << endl;
			wcout << L"    " << loopChar(L'=', indexLength) << L"    " << loopChar(L'=', widLength) << L"    " << loopChar(L'=', cnLength) << L"    " << loopChar(L'=', tnLength) << endl;
			for (size_t i = 0; i < vectorLength; ++i)
				wcout << L"    " << setw(indexLength) << i << L"    " << setw(widLength) << hWnds[i] << L"    " << setw(cnLength) << classNames[i] << L"    " << setw(tnLength) << titleNames[i] << endl;
			wcout << endl << L"Please select an index to continue (default = 0): ";
			rewind(stdin);
			fflush(stdin);
			cin >> choice;
			if (choice < vectorLength)
			{
				this->windowID = hWnds[choice];
				//////
				return this->getWindowRectangle();
			}
			else
			{
				wcout << L"The PID has not been confirmed. " << endl;
				return false;
			}
		}
		else if (hWnds.size() == 1)
		{
			this->windowID = hWnds[0];
			return this->getWindowRectangle();
		}
		else
		{
			wcout << L"Failed to find the window according to the process ID and the window title with error code " << GetLastError() << L". " << endl;
			return false;
		}
	}
	bool getImageNameByProcessID()
	{
		const HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processID);
		if (nullptr == hProcess)
		{
			wcout << L"Failed to open process with PID " << this->processID << ". " << endl;
			return false;
		}

		wchar_t buffer[MAX_PATH + 1] = { NULL };
		if (GetModuleBaseName(hProcess, nullptr, buffer, MAX_PATH) > 0)
		{
			this->processName = buffer;
			CloseHandle(hProcess);
			wcout << L"The process name of the process with PID " << this->processID << L" is \"" << this->processName << L"\". " << endl;
			return this->getWindowID();
		}
		else
		{
			wcout << L"Failed to get the process name of the process with PID " << this->processID << L". " << endl;
			CloseHandle(hProcess);
			return false;
		}
	}
	bool getProcessIDByImageName()
	{
		/* Create the snapshot */
		HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		if (INVALID_HANDLE_VALUE == snapshot)
			return false;

		/* Fetch the first block */
		PROCESSENTRY32 processEntry{};
		processEntry.dwSize = sizeof(PROCESSENTRY32);
		if (!Process32First(snapshot, &processEntry))
		{
			CloseHandle(snapshot);
			return false;
		}

		/* Walk through all the blocks */
		vector<DWORD> pids{};
		vector<wstring> processNames{};
		wstring upperImageName = this->processName;
		CharUpperBuff(&upperImageName[0], (DWORD)upperImageName.length());
		do
		{
			wstring upperSzExeFile = (wstring)processEntry.szExeFile;
			CharUpperBuff(&upperSzExeFile[0], (DWORD)upperSzExeFile.length());
			if (upperImageName.compare(upperSzExeFile) == 0)
			{
				pids.push_back(processEntry.th32ProcessID);
				processNames.push_back(processEntry.szExeFile);
			}
		} while (Process32Next(snapshot, &processEntry));
		CloseHandle(snapshot);

		/* Select the final PID */
		if (!pids.empty() && !processNames.empty() && pids.size() == processNames.size())
			if (1 == pids.size())
			{
				this->processID = pids[0];
				return this->getWindowID();
			}
			else
			{
				size_t choice = NULL;
				const size_t vectorLength = pids.size();
				const size_t indexLength = max(to_string(vectorLength - 1).size(), 5);
				const size_t pidLength = max(to_string(*max_element(pids.begin(), pids.end())).size(), 3);
				const size_t pnLength = max((*max_element(processNames.begin(), processNames.end(), [](const wstring& pn1, const wstring& pn2) { return pn1.length() < pn2.length(); })).length(), 12);
				wcout << L"Multiple processes have the same process name. " << endl << endl;
				wcout << L"    " << setw(indexLength) << L"Index" << L"    " << setw(pidLength) << L"PID" << L"    " << setw(pnLength) << "Process Name" << endl;
				wcout << L"    " << loopChar(L'=', indexLength) << L"    " << loopChar(L'=', pidLength) << L"    " << loopChar(L'=', pnLength) << endl;
				for (size_t i = 0; i < vectorLength; ++i)
					wcout << L"    " << setw(indexLength) << i << L"    " << setw(pidLength) << pids[i] << L"    " << setw(pnLength) << processNames[i] << endl;
				wcout << endl << L"Please select an index to continue (default = 0): ";
				rewind(stdin);
				fflush(stdin);
				cin >> choice;
				if (choice < vectorLength)
				{
					this->processID = pids[choice];
					return this->getWindowID();
				}
				else
				{
					wcout << L"The PID has not been confirmed. " << endl;
					return false;
				}
			}
		else
			return false;
	}
	
public:
	AutoAobi(DWORD processID, LPCWSTR windowClassName, LPCWSTR windowTitle)
	{
		this->processID = processID;
		this->windowClassName = windowClassName;
		this->windowTitle = windowTitle;
		this->getImageNameByProcessID();
	}
	AutoAobi(wstring processName, LPCWSTR windowClassName, LPCWSTR windowTitle)
	{
		this->processName = processName;
		this->windowClassName = windowClassName;
		this->windowTitle = windowTitle;
		this->getProcessIDByImageName();
	}
	
	bool sleep(DWORD dwMilliseconds)
	{
		try
		{
			Sleep(dwMilliseconds);
			return true;
		}
		catch (...)
		{
			return false;
		}
	}
	bool setForeGroundWindow() const
	{
		return SetForegroundWindow(this->windowID);
	}
	bool CaptureScreen(const wstring outputFilePath)
	{
		HDC screenDC = GetDC(NULL);
		const LONG desW = this->windowRectangle.right - this->windowRectangle.left; // GetDeviceCaps(screenDC, HORZRES);
		const LONG desH = this->windowRectangle.bottom - this->windowRectangle.top; // GetDeviceCaps(screenDC, VERTRES);

		HDC memDC = CreateCompatibleDC(screenDC);
		HBITMAP hBitmap = CreateCompatibleBitmap(screenDC, desW, desH);
		HBITMAP hBitmapOld = (HBITMAP)SelectObject(memDC, hBitmap);

		BitBlt(memDC, 0, 0, desW, desH, screenDC, this->windowRectangle.left, this->windowRectangle.top, SRCCOPY);

		BITMAPINFOHEADER bi;
		bi.biSize = sizeof(BITMAPINFOHEADER);
		bi.biWidth = desW;
		bi.biHeight = desH;
		bi.biPlanes = 1;
		bi.biBitCount = 24;
		bi.biCompression = BI_RGB;
		bi.biSizeImage = 0;
		bi.biXPelsPerMeter = 0;
		bi.biYPelsPerMeter = 0;
		bi.biClrUsed = 0;
		bi.biClrImportant = 0;

		DWORD dwBmpSize = ((desW * bi.biBitCount + 31) / 32) * 4 * desH;
		HANDLE hDib = GlobalAlloc(GHND, dwBmpSize);
		if (!hDib)
		{
			wcout << L"Failed to allocate the BMP memory. " << endl;
			return false;
		}
		char* lpbitmap = (char*)GlobalLock(hDib);
		if (!lpbitmap)
		{
			GlobalFree(hDib);
			wcout << L"Failed to lock the allocated block. " << endl;
			return false;
		}
		GetDIBits(screenDC, hBitmap, 0, desH, lpbitmap, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

		FILE* file;
		bool fileFlag = true;
		_wfopen_s(&file, outputFilePath.c_str(), L"wb");
		if (file)
		{
			BITMAPFILEHEADER bf;
			bf.bfType = 0x4D42;
			bf.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + dwBmpSize;
			bf.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

			fwrite(&bf, sizeof(BITMAPFILEHEADER), 1, file);
			fwrite(&bi, sizeof(BITMAPINFOHEADER), 1, file);
			fwrite(lpbitmap, dwBmpSize, 1, file);
			fclose(file);
		}
		else
		{
			wcout << L"Failed to write the screenshot to the file \"" << outputFilePath << L"\". " << endl;
			fileFlag = false;
		}

		GlobalUnlock(hDib);
		GlobalFree(hDib);
		SelectObject(memDC, hBitmapOld);
		DeleteDC(memDC);
		ReleaseDC(NULL, screenDC);
		DeleteObject(hBitmap);

		wcout << L"Successfully write the screenshot to the file \"" << outputFilePath << L"\". " << endl;
		return fileFlag;
	}
};



int main()
{
	setlocale(LC_ALL, "zh_CN.UTF-8");
	AutoAobi autoAobi = AutoAobi(L"notepad.exe", NULL, NULL);
	return autoAobi.sleep(5000) && autoAobi.CaptureScreen(L"D:\\screenshot.bmp") ? EXIT_SUCCESS : EXIT_FAILURE;
}